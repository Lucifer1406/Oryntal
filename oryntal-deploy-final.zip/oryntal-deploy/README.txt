ORYNTAL WEBSITE — VERCEL DEPLOYMENT
=====================================

OPTION 1 — GITHUB (Recommended for auto-deploy):
1. Upload all files in this folder to your GitHub repo: Lucifer1406/Oryntal
2. Go to vercel.com → oryntal project → Settings
3. Set Output Directory to: .  (just a dot)
4. Redeploy — your site will be live!

OPTION 2 — VERCEL CLI (One command):
1. Install Node.js from nodejs.org
2. Open terminal in this folder
3. Run: npx vercel --prod
4. Login to Vercel when prompted
5. Done! Live URL printed in terminal.

OPTION 3 — DRAG & DROP:
1. Go to vercel.com/new
2. Click "Deploy without Git"  
3. Drag this entire folder into Vercel
4. Live in 30 seconds!

Files in this package:
- index.html     → Your complete Oryntal website
- vercel.json    → Vercel routing config
- deploy.sh      → Auto-deploy script
