#!/bin/bash
echo "🚀 Deploying Oryntal to Vercel..."

# Install Vercel CLI if not present
if ! command -v vercel &> /dev/null; then
  echo "Installing Vercel CLI..."
  npm install -g vercel
fi

# Go to script directory
cd "$(dirname "$0")"

# Deploy directly to production
vercel --prod --yes --name oryntal

echo "✅ Done! Your site is live."
